import 'package:flutter/material.dart';
import 'package:my_health/constants.dart';
class RecentResult extends StatelessWidget {
  const RecentResult({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Center(
          child: SizedBox(
            height: 300.0,
            width: 400.0,
            child: Card(
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.white70, width: 1),
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 10.0,
              child: Column(
                //TODO:Take The Last Results
                children: <Widget>[
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: <Widget>[
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        'Heart Rate: 86 bpm',
                        style:
                        TextStyle(fontSize: 16.0, color: kPrimaryColor),
                      ),
                      SizedBox(
                        width: 100,
                      ),
                      Expanded(
                        child: Text(
                          'SPO2: 96%',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                      ),
                    ],
                  ),

                  Row(
                    children: [
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        'Temperature: 36.5',
                        style: TextStyle(
                          fontSize: 16.0,
                          color: kPrimaryColor,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Image.asset(
                    'assets/images/ecg.png',
                    height: 80.0,
                    width: double.infinity,
                  ),

                  SizedBox(
                    height: 80,
                  ),
                  Expanded(
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          'Time: 7:00 pm',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                        SizedBox(
                          width: 100,
                        ),
                        Expanded(
                          child: Text(
                            'Date: 28/3/2021',
                            style:
                            TextStyle(fontSize: 16.0, color: kPrimaryColor),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        //TODO: Decide the results status
                        'Status: Normal/abnormal',
                        style: TextStyle(
                          fontSize: 16.0,
                          color: kPrimaryColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}