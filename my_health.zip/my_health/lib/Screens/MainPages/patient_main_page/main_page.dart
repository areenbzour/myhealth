import 'package:flutter/material.dart';
import 'package:my_health/Screens/MainPages/patient_main_page/components/body.dart';
import 'components/body.dart';
class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}