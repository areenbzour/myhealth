import 'package:flutter/material.dart';
import 'background.dart';
class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Background(
      child: Column(

      ),
    );
  }
}
