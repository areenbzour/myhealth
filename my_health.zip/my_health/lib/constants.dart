import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF8F0100);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const kFontSize= 20.0;
const MaterialColor txtColor= MaterialColor(0xFF8F0100, <int, Color>{
  50:Color(0xFF8F0100),
  100: Color(0xFF8F0100),
  200: Color(0xFF8F0100),
  300: Color(0xFF8F0100),
  400: Color(0xFF8F0100),
  500: Color(0xFF8F0100),
  600: Color(0xFF8F0100),
  700: Color(0xFF8F0100),
  800:Color(0xFF8F0100),
  900:Color(0xFF8F0100),
});